import { MongoClient, ServerApiVersion } from 'mongodb'

const uri = 'mongodb+srv://germanlopezguerrero:4i3K8nBb2WB4Rc0K@eva-u3-express.fgsv7.mongodb.net/?retryWrites=true&w=majority&appName=eva-u3-express'

const client = new MongoClient(uri, {
    serverApi:{
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true
    }
})

export default client